cancer_cor <- cor(cancer_norm, method="pearson") #create similarity matrix of correlations
head(cancer_cor)  #not shown on this page