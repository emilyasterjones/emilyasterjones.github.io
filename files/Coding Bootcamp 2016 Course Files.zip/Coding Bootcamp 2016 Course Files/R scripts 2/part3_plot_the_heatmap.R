#make a heatmap
heatmap(cancer_norm[1:20,], Rowv=NA, labRow=NA, labCol=NA) #plot a heatmap
library(RColorBrewer)
display.brewer.all()
heatmap(cancer_norm[1:20,], Rowv=NA, labRow=NA, labCol=NA, col=brewer.pal(9,'Oranges')) #make the colormap better
