#make a dendrogram using hierarhical clustering
install.packages("RFLPtools") #install package to convert similarity matrix to distance matrix
library("RFLPtools")
cancer_dist <- sim2dist(cancer_cor) #calculate distance matrix for clustering
cancer_clust <- hclust(cancer_dist, method="average") #hierarchical clustering
plot(cancer_clust) #take a look at our clustering